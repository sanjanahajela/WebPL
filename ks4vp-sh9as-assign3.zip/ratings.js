//Kajal Sheth(ks4vp) and Sanjana Hajela (sh9as)
function checkName(firstname){
    document.getElementById(firstname)
    if(document.getElementById(firstname).length==0){
    	alert("Please enter a first name")

    }
}